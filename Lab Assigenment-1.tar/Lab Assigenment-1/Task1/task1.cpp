#include <iostream>
using namespace std;

int main() {
    int num = 10;
    float decimal = 5.5;
    char letter = 'A';
    string name = "Ali";

    cout << "Integer: " << num << endl;
    cout << "Float: " << decimal << endl;
    cout << "Character: " << letter << endl;
    cout << "String: " << name << endl;

    return 0;
}