#include <iostream>
using namespace std;

int main() {
    int a = 10;
    float b = 3.14;
    char c = 'A';

    cout << "Value of a: " << a << endl;
    cout << "Value of b: " << b << endl;
    cout << "Value of c: " << c << endl;

    return 0;
}