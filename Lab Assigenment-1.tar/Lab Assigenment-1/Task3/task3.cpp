#include <iostream>
using namespace std;

int main() {
    // num1 stores an integer value (whole number)
    int num1 = 25;

    // num2 stores a decimal number
    float num2 = 7.5;

    // letter stores a single character
    char letter = 'Z';

    cout << "Integer value (num1): " << num1 << endl;
    cout << "Float value (num2): " << num2 << endl;
    cout << "Character (letter): " << letter << endl;

    return 0;
}